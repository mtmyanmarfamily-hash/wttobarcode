package com.myanmar.wheeltax

import android.Manifest
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.MultiFormatWriter
import java.io.File
import java.io.FileOutputStream

class MainActivity : AppCompatActivity() {

    private lateinit var ivFront: ImageView
    private lateinit var ivBack: ImageView
    private lateinit var layoutFrontResult: LinearLayout
    private lateinit var layoutBackResult: LinearLayout
    private lateinit var etPlate: EditText
    private lateinit var etChassis: EditText
    private lateinit var etExpiry: EditText
    private lateinit var btnGenerate: Button
    private lateinit var cardBarcode: CardView
    private lateinit var ivBarcode: ImageView
    private lateinit var tvBarcodeData: TextView
    private lateinit var btnSave: Button
    private lateinit var btnShare: Button

    private var currentBitmap: Bitmap? = null
    private var cameraUri: Uri? = null

    private val REQ_CAMERA_FRONT  = 101
    private val REQ_GALLERY_FRONT = 102
    private val REQ_CAMERA_BACK   = 103
    private val REQ_GALLERY_BACK  = 104
    private val REQ_PERMISSIONS    = 200

    private var pendingAction: (() -> Unit)? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        ivFront = findViewById(R.id.ivFront)
        ivBack = findViewById(R.id.ivBack)
        layoutFrontResult = findViewById(R.id.layoutFrontResult)
        layoutBackResult = findViewById(R.id.layoutBackResult)
        etPlate = findViewById(R.id.etPlate)
        etChassis = findViewById(R.id.etChassis)
        etExpiry = findViewById(R.id.etExpiry)
        btnGenerate = findViewById(R.id.btnGenerate)
        cardBarcode = findViewById(R.id.cardBarcode)
        ivBarcode = findViewById(R.id.ivBarcode)
        tvBarcodeData = findViewById(R.id.tvBarcodeData)
        btnSave = findViewById(R.id.btnSave)
        btnShare = findViewById(R.id.btnShare)

        findViewById<Button>(R.id.btnCaptureFront).setOnClickListener { checkAndRun { openCamera(REQ_CAMERA_FRONT) } }
        findViewById<Button>(R.id.btnGalleryFront).setOnClickListener { checkAndRun { openGallery(REQ_GALLERY_FRONT) } }
        findViewById<Button>(R.id.btnCaptureBack).setOnClickListener { checkAndRun { openCamera(REQ_CAMERA_BACK) } }
        findViewById<Button>(R.id.btnGalleryBack).setOnClickListener { checkAndRun { openGallery(REQ_GALLERY_BACK) } }

        btnGenerate.setOnClickListener { generateBarcode() }
        btnSave.setOnClickListener { saveBarcode() }
        btnShare.setOnClickListener { shareBarcode() }
    }

    private fun checkAndRun(action: () -> Unit) {
        val perms = mutableListOf(Manifest.permission.CAMERA)
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            perms.add(Manifest.permission.READ_EXTERNAL_STORAGE)
            perms.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }
        val missing = perms.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isEmpty()) action() else {
            pendingAction = action
            ActivityCompat.requestPermissions(this, missing.toTypedArray(), REQ_PERMISSIONS)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (grantResults.all { it == PackageManager.PERMISSION_GRANTED }) pendingAction?.invoke()
        pendingAction = null
    }

    private fun openCamera(requestCode: Int) {
        val photoFile = File.createTempFile("wtax_", ".jpg", externalCacheDir)
        cameraUri = FileProvider.getUriForFile(this, "$packageName.provider", photoFile)
        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE).apply { putExtra(MediaStore.EXTRA_OUTPUT, cameraUri) }
        startActivityForResult(intent, requestCode)
    }

    private fun openGallery(requestCode: Int) {
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        startActivityForResult(intent, requestCode)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        when (requestCode) {
            REQ_CAMERA_FRONT -> cameraUri?.let { processImage(it, true) }
            REQ_GALLERY_FRONT -> data?.data?.let { processImage(it, true) }
            REQ_CAMERA_BACK -> cameraUri?.let { processImage(it, false) }
            REQ_GALLERY_BACK -> data?.data?.let { processImage(it, false) }
        }
    }

    private fun processImage(uri: Uri, isFront: Boolean) {
        try {
            val stream = contentResolver.openInputStream(uri) ?: return
            val bitmap = BitmapFactory.decodeStream(stream)
            stream.close()

            if (isFront) ivFront.setImageBitmap(bitmap) else ivBack.setImageBitmap(bitmap)

            val image = InputImage.fromBitmap(bitmap, 0)
            val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

            recognizer.process(image).addOnSuccessListener { result ->
                if (isFront) {
                    etPlate.setText(extractPlateNumber(result.text.uppercase()))
                    layoutFrontResult.visibility = View.VISIBLE
                } else {
                    etChassis.setText(extractChassis(result.text))
                    etExpiry.setText(extractExpiry(result.text))
                    layoutBackResult.visibility = View.VISIBLE
                }
                if (etPlate.text.isNotEmpty() && etChassis.text.isNotEmpty()) {
                    btnGenerate.visibility = View.VISIBLE
                }
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Image Error", Toast.LENGTH_SHORT).show()
        }
    }

    private fun extractPlateNumber(text: String): String {
        // Strict 4-digit plate regex
        val regex = Regex("""([0-9A-Z][A-Z][/\-]\d{4})""")
        return regex.find(text)?.value ?: ""
    }

    private fun extractChassis(text: String): String {
        val lines = text.split("\n")
        // Chassis must be 6-18 chars, Alphanumeric, often has a dash
        val chassisPattern = Regex("""([A-Z0-9]{3,8}[-]?[A-Z0-9]{4,10})""")
        
        // Words to ignore so we don't pick up labels
        val blacklist = listOf("CHARACTER", "VEHICLE", "GROSS", "WEIGHT", "ENGINE", "PRIVATE")

        for (i in lines.indices) {
            val line = lines[i].uppercase()
            if (line.contains("CHASSIS") || line.contains("CHASIS")) {
                // Check same line
                val match = chassisPattern.find(line.replace("CHASSIS", "").replace("NO", ""))
                if (match != null && !blacklist.any { match.value.contains(it) }) {
                    return match.value
                }
                
                // Check next 2 lines (OCR sometimes jumps)
                for (j in 1..2) {
                    if (i + j < lines.size) {
                        val nextLine = lines[i+j].uppercase().trim()
                        val nextMatch = chassisPattern.find(nextLine)
                        if (nextMatch != null && !blacklist.any { nextMatch.value.contains(it) }) {
                            return nextMatch.value
                        }
                    }
                }
            }
        }
        return ""
    }

    private fun extractExpiry(text: String): String {
        val lines = text.split("\n")
        val dateRegex = Regex("""(\d{2}[/\-]\d{2}[/\-]\d{4})""")
        for (i in lines.indices) {
            val line = lines[i].uppercase()
            if (line.contains("VALID") || line.contains("UP TO")) {
                val match = dateRegex.find(line) ?: if (i+1 < lines.size) dateRegex.find(lines[i+1]) else null
                if (match != null) return match.value.replace("-", "/")
            }
        }
        return ""
    }

    private fun generateBarcode() {
        val plate = etPlate.text.toString().trim()
        val chassis = etChassis.text.toString().trim()
        val expiry = etExpiry.text.toString().trim()
        // Data for barcode: remove all non-alphanumeric chars
        val data = "$plate$chassis$expiry".uppercase().replace(Regex("[^A-Z0-9]"), "")
        
        if (data.isEmpty()) return

        try {
            val writer = MultiFormatWriter()
            val matrix = writer.encode(data, BarcodeFormat.PDF_417, 900, 300, mapOf(EncodeHintType.MARGIN to 2))
            val bmp = Bitmap.createBitmap(matrix.width, matrix.height, Bitmap.Config.ARGB_8888)
            for (x in 0 until matrix.width) {
                for (y in 0 until matrix.height) {
                    bmp.setPixel(x, y, if (matrix[x, y]) Color.BLACK else Color.WHITE)
                }
            }
            currentBitmap = bmp
            ivBarcode.setImageBitmap(bmp)
            tvBarcodeData.text = "Data: $data"
            cardBarcode.visibility = View.VISIBLE
        } catch (e: Exception) {
            Toast.makeText(this, "Barcode Error", Toast.LENGTH_SHORT).show()
        }
    }

    private fun saveBarcode() {
        val bmp = currentBitmap ?: return
        val name = "WT_${System.currentTimeMillis()}.png"
        try {
            val cv = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, name)
                put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q)
                    put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/WheelTax")
            }
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)
            uri?.let {
                contentResolver.openOutputStream(it)?.use { out -> bmp.compress(Bitmap.CompressFormat.PNG, 100, out) }
                Toast.makeText(this, "Saved to Gallery", Toast.LENGTH_SHORT).show()
            }
        } catch (e: Exception) { Toast.makeText(this, "Save Failed", Toast.LENGTH_SHORT).show() }
    }

    private fun shareBarcode() {
        val bmp = currentBitmap ?: return
        val file = File(cacheDir, "shared_barcode.png")
        FileOutputStream(file).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        val uri = FileProvider.getUriForFile(this, "$packageName.provider", file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "image/png"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(intent, "Share"))
    }
}
