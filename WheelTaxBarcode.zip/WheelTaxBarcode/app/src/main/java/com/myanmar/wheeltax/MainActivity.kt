package com.myanmar.wheeltax

import android.Manifest
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.MultiFormatWriter
import java.io.File
import java.io.FileOutputStream

class MainActivity : AppCompatActivity() {

    private lateinit var ivFront: ImageView
    private lateinit var ivBack: ImageView
    private lateinit var layoutFrontResult: LinearLayout
    private lateinit var layoutBackResult: LinearLayout
    private lateinit var etPlate: EditText
    private lateinit var etChassis: EditText
    private lateinit var etExpiry: EditText
    private lateinit var btnGenerate: Button
    private lateinit var cardBarcode: CardView
    private lateinit var ivBarcode: ImageView
    private lateinit var tvBarcodeData: TextView
    private lateinit var btnSave: Button
    private lateinit var btnShare: Button

    private var currentBitmap: Bitmap? = null
    private var cameraUri: Uri? = null

    private val REQ_CAMERA_FRONT  = 101
    private val REQ_GALLERY_FRONT = 102
    private val REQ_CAMERA_BACK   = 103
    private val REQ_GALLERY_BACK  = 104
    private val REQ_PERMISSIONS    = 200

    private var pendingAction: (() -> Unit)? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        ivFront           = findViewById(R.id.ivFront)
        ivBack           = findViewById(R.id.ivBack)
        layoutFrontResult = findViewById(R.id.layoutFrontResult)
        layoutBackResult  = findViewById(R.id.layoutBackResult)
        etPlate           = findViewById(R.id.etPlate)
        etChassis         = findViewById(R.id.etChassis)
        etExpiry          = findViewById(R.id.etExpiry)
        btnGenerate       = findViewById(R.id.btnGenerate)
        cardBarcode       = findViewById(R.id.cardBarcode)
        ivBarcode         = findViewById(R.id.ivBarcode)
        tvBarcodeData     = findViewById(R.id.tvBarcodeData)
        btnSave           = findViewById(R.id.btnSave)
        btnShare          = findViewById(R.id.btnShare)

        findViewById<Button>(R.id.btnCaptureFront).setOnClickListener { checkAndRun { openCamera(REQ_CAMERA_FRONT) } }
        findViewById<Button>(R.id.btnGalleryFront).setOnClickListener { checkAndRun { openGallery(REQ_GALLERY_FRONT) } }
        findViewById<Button>(R.id.btnCaptureBack).setOnClickListener  { checkAndRun { openCamera(REQ_CAMERA_BACK) } }
        findViewById<Button>(R.id.btnGalleryBack).setOnClickListener   { checkAndRun { openGallery(REQ_GALLERY_BACK) } }

        btnGenerate.setOnClickListener { generateBarcode() }
        btnSave.setOnClickListener    { saveBarcode() }
        btnShare.setOnClickListener   { shareBarcode() }
    }

    private fun checkAndRun(action: () -> Unit) {
        val perms = mutableListOf(Manifest.permission.CAMERA)
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            perms.add(Manifest.permission.READ_EXTERNAL_STORAGE)
            perms.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }
        val missing = perms.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isEmpty()) action() else {
            pendingAction = action
            ActivityCompat.requestPermissions(this, missing.toTypedArray(), REQ_PERMISSIONS)
        }
    }

    private fun openCamera(requestCode: Int) {
        val photoFile = File.createTempFile("wtax_", ".jpg", externalCacheDir)
        cameraUri = FileProvider.getUriForFile(this, "$packageName.provider", photoFile)
        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE).apply { putExtra(MediaStore.EXTRA_OUTPUT, cameraUri) }
        startActivityForResult(intent, requestCode)
    }

    private fun openGallery(requestCode: Int) {
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        startActivityForResult(intent, requestCode)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        when (requestCode) {
            REQ_CAMERA_FRONT  -> cameraUri?.let { processImage(it, true) }
            REQ_GALLERY_FRONT -> data?.data?.let { processImage(it, true) }
            REQ_CAMERA_BACK   -> cameraUri?.let { processImage(it, false) }
            REQ_GALLERY_BACK  -> data?.data?.let { processImage(it, false) }
        }
    }

    private fun processImage(uri: Uri, isFront: Boolean) {
        val stream = contentResolver.openInputStream(uri) ?: return
        val bitmap = BitmapFactory.decodeStream(stream)
        stream.close()

        if (isFront) ivFront.setImageBitmap(bitmap) else ivBack.setImageBitmap(bitmap)

        val image = InputImage.fromBitmap(bitmap, 0)
        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

        recognizer.process(image)
            .addOnSuccessListener { result ->
                val fullText = result.text // Keep case for extraction logic
                if (isFront) {
                    etPlate.setText(extractPlateNumber(fullText.uppercase()))
                    layoutFrontResult.visibility = View.VISIBLE
                } else {
                    etChassis.setText(extractChassis(fullText))
                    etExpiry.setText(extractExpiry(fullText))
                    layoutBackResult.visibility = View.VISIBLE
                }
                checkShowGenerateButton()
            }
    }

    // --- UPDATED EXTRACTION LOGIC ---

    private fun extractPlateNumber(text: String): String {
        val regex = Regex("""(\d[A-Z][/\-]\d{4})""")
        return regex.find(text)?.value ?: ""
    }

    private fun extractChassis(text: String): String {
        val lines = text.split("\n")
        // This regex looks for 6-17 chars of alphanumeric/dash (Standard Chassis/VIN formats)
        val chassisPattern = Regex("""([A-Z0-9\-]{6,18})""")

        for (i in lines.indices) {
            val line = lines[i].uppercase()
            // Specifically look for "CHASSIS" label to avoid "ENGINE" label above it
            if (line.contains("CHASSIS") || line.contains("CHASIS")) {
                
                // Try to find the number on the same line after the label
                val remainingLine = line.substringAfter("NO").trim()
                val match = chassisPattern.find(remainingLine)
                if (match != null) return match.value

                // If not found on same line, check the next line (common in photo OCR)
                if (i + 1 < lines.size) {
                    val nextLineMatch = chassisPattern.find(lines[i+1].uppercase().trim())
                    if (nextLineMatch != null) return nextLineMatch.value
                }
            }
        }
        
        // Final fallback: look for standard Myanmar MA3 style prefixes anywhere
        return Regex("""MA[A-Z0-9\-]{5,}""").find(text.uppercase())?.value ?: ""
    }

    private fun extractExpiry(text: String): String {
        val regex = Regex("""(\d{2}[/\-]\d{2}[/\-]\d{4})""")
        return regex.find(text)?.value?.replace("-", "/") ?: ""
    }

    private fun checkShowGenerateButton() {
        if (layoutFrontResult.visibility == View.VISIBLE && layoutBackResult.visibility == View.VISIBLE) {
            btnGenerate.visibility = View.VISIBLE
        }
    }

    private fun generateBarcode() {
        val data = "${etPlate.text}${etChassis.text}${etExpiry.text}".uppercase().replace(" ", "")
        try {
            val writer = MultiFormatWriter()
            val matrix = writer.encode(data, BarcodeFormat.PDF_417, 900, 300, mapOf(EncodeHintType.MARGIN to 2))
            val bmp = Bitmap.createBitmap(matrix.width, matrix.height, Bitmap.Config.ARGB_8888)
            for (x in 0 until matrix.width) {
                for (y in 0 until matrix.height) {
                    bmp.setPixel(x, y, if (matrix[x, y]) Color.BLACK else Color.WHITE)
                }
            }
            currentBitmap = bmp
            ivBarcode.setImageBitmap(bmp)
            tvBarcodeData.text = "Data: $data"
            cardBarcode.visibility = View.VISIBLE
        } catch (e: Exception) {
            Toast.makeText(this, "Barcode Error", Toast.LENGTH_SHORT).show()
        }
    }

    private fun saveBarcode() {
        val bmp = currentBitmap ?: return
        val name = "WT_${System.currentTimeMillis()}.png"
        try {
            val cv = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, name)
                put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) 
                    put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/WheelTax")
            }
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)
            uri?.let {
                contentResolver.openOutputStream(it)?.use { out -> bmp.compress(Bitmap.CompressFormat.PNG, 100, out) }
                Toast.makeText(this, "Saved to Gallery", Toast.LENGTH_SHORT).show()
            }
        } catch (e: Exception) { Toast.makeText(this, "Save Failed", Toast.LENGTH_SHORT).show() }
    }

    private fun shareBarcode() {
        val bmp = currentBitmap ?: return
        val file = File(cacheDir, "shared_barcode.png")
        FileOutputStream(file).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        val uri = FileProvider.getUriForFile(this, "$packageName.provider", file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "image/png"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(intent, "Share"))
    }
}
