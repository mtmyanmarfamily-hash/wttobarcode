package com.myanmar.wheeltax

import android.Manifest
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.MultiFormatWriter
import java.io.File
import java.io.FileOutputStream

class MainActivity : AppCompatActivity() {

    private lateinit var etPlate: EditText
    private lateinit var etChassis: EditText
    private lateinit var etExpiry: EditText
    private lateinit var layoutFrontResult: LinearLayout
    private lateinit var layoutBackResult: LinearLayout
    private lateinit var btnGenerate: Button
    private lateinit var cardBarcode: CardView
    private lateinit var ivBarcode: ImageView
    private lateinit var tvBarcodeData: TextView
    private var currentBitmap: Bitmap? = null
    private var cameraUri: Uri? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Init views
        etPlate = findViewById(R.id.etPlate)
        etChassis = findViewById(R.id.etChassis)
        etExpiry = findViewById(R.id.etExpiry)
        layoutFrontResult = findViewById(R.id.layoutFrontResult)
        layoutBackResult = findViewById(R.id.layoutBackResult)
        btnGenerate = findViewById(R.id.btnGenerate)
        cardBarcode = findViewById(R.id.cardBarcode)
        ivBarcode = findViewById(R.id.ivBarcode)
        tvBarcodeData = findViewById(R.id.tvBarcodeData)

        findViewById<Button>(R.id.btnCaptureFront).setOnClickListener { openCamera(101) }
        findViewById<Button>(R.id.btnGalleryFront).setOnClickListener { openGallery(102) }
        findViewById<Button>(R.id.btnCaptureBack).setOnClickListener { openCamera(103) }
        findViewById<Button>(R.id.btnGalleryBack).setOnClickListener { openGallery(104) }

        findViewById<Button>(R.id.btnGenerate).setOnClickListener { generateBarcode() }
        findViewById<Button>(R.id.btnSave).setOnClickListener { saveBarcode() }
        findViewById<Button>(R.id.btnShare).setOnClickListener { shareBarcode() }
    }

    private fun openCamera(req: Int) {
        val file = File.createTempFile("tax_", ".jpg", externalCacheDir)
        cameraUri = FileProvider.getUriForFile(this, "$packageName.provider", file)
        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE).apply { putExtra(MediaStore.EXTRA_OUTPUT, cameraUri) }
        startActivityForResult(intent, req)
    }

    private fun openGallery(req: Int) {
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        startActivityForResult(intent, req)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        
        val uri = if (requestCode == 101 || requestCode == 103) cameraUri else data?.data
        uri?.let { processOCR(it, requestCode == 101 || requestCode == 102) }
    }

    private fun processOCR(uri: Uri, isFront: Boolean) {
        val bitmap = BitmapFactory.decodeStream(contentResolver.openInputStream(uri))
        val image = InputImage.fromBitmap(bitmap, 0)
        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

        // Clear existing data before new scan to avoid showing old values
        if (isFront) etPlate.setText("") else {
            etChassis.setText("")
            etExpiry.setText("")
        }

        recognizer.process(image).addOnSuccessListener { result ->
            val lines = result.textBlocks.flatMap { it.lines }
            
            if (isFront) {
                val plateRegex = Regex("""([0-9A-Z][A-Z][/\-]\d{4})""")
                etPlate.setText(plateRegex.find(result.text.uppercase())?.value ?: "")
                layoutFrontResult.visibility = View.VISIBLE
            } else {
                // Improved Chassis Detection: Look for text near "CHASSIS" label
                val chassisPattern = Regex("""([A-Z0-9]{3,8}[-]?[A-Z0-9]{4,10})""")
                for (i in lines.indices) {
                    val txt = lines[i].text.uppercase()
                    if (txt.contains("CHASSIS") || txt.contains("CHASIS")) {
                        // Check same line or next line
                        val combine = txt + " " + (if (i + 1 < lines.size) lines[i+1].text.uppercase() else "")
                        val match = chassisPattern.find(combine.replace("CHASSIS", "").replace("NO", ""))
                        if (match != null) {
                            etChassis.setText(match.value)
                            break
                        }
                    }
                }

                // Improved Expiry Detection: Look specifically for "Valid up to"
                val dateRegex = Regex("""(\d{2}[/\-]\d{2}[/\-]\d{4})""")
                for (i in lines.indices) {
                    val txt = lines[i].text.uppercase()
                    if (txt.contains("VALID") || txt.contains("UP TO")) {
                        val searchArea = txt + " " + (if (i + 1 < lines.size) lines[i+1].text.uppercase() else "")
                        val dateMatch = dateRegex.find(searchArea)
                        if (dateMatch != null) {
                            etExpiry.setText(dateMatch.value.replace("-", "/"))
                            break
                        }
                    }
                }
                layoutBackResult.visibility = View.VISIBLE
            }
            if (etPlate.text.isNotEmpty() && etChassis.text.isNotEmpty()) {
                btnGenerate.visibility = View.VISIBLE
            }
        }
    }

    private fun generateBarcode() {
        val data = "${etPlate.text}${etChassis.text}${etExpiry.text}".uppercase().replace(Regex("[^A-Z0-9]"), "")
        if (data.isEmpty()) return
        try {
            val matrix = MultiFormatWriter().encode(data, BarcodeFormat.PDF_417, 900, 300, mapOf(EncodeHintType.MARGIN to 2))
            val bmp = Bitmap.createBitmap(matrix.width, matrix.height, Bitmap.Config.ARGB_8888)
            for (x in 0 until matrix.width) {
                for (y in 0 until matrix.height) bmp.setPixel(x, y, if (matrix[x, y]) Color.BLACK else Color.WHITE)
            }
            currentBitmap = bmp
            ivBarcode.setImageBitmap(bmp)
            tvBarcodeData.text = "Data: $data"
            cardBarcode.visibility = View.VISIBLE
        } catch (e: Exception) { Toast.makeText(this, "Error", Toast.LENGTH_SHORT).show() }
    }

    private fun saveBarcode() {
        val bmp = currentBitmap ?: return
        val cv = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "WT_${System.currentTimeMillis()}.png")
            put(MediaStore.Images.Media.MIME_TYPE, "image/png")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q)
                put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/WheelTax")
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)
        uri?.let {
            contentResolver.openOutputStream(it)?.use { out -> bmp.compress(Bitmap.CompressFormat.PNG, 100, out) }
            Toast.makeText(this, "Saved!", Toast.LENGTH_SHORT).show()
        }
    }

    private fun shareBarcode() {
        val bmp = currentBitmap ?: return
        val file = File(cacheDir, "share.png")
        FileOutputStream(file).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        val uri = FileProvider.getUriForFile(this, "$packageName.provider", file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "image/png"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(intent, "Share"))
    }
}
