package com.myanmar.wheeltax

import android.Manifest
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.MultiFormatWriter
import java.io.File
import java.io.FileOutputStream

class MainActivity : AppCompatActivity() {

    // Views
    private lateinit var ivFront: ImageView
    private lateinit var ivBack: ImageView
    private lateinit var layoutFrontResult: LinearLayout
    private lateinit var layoutBackResult: LinearLayout
    private lateinit var etPlate: EditText
    private lateinit var etChassis: EditText
    private lateinit var etExpiry: EditText
    private lateinit var btnGenerate: Button
    private lateinit var cardBarcode: CardView
    private lateinit var ivBarcode: ImageView
    private lateinit var tvBarcodeData: TextView
    private lateinit var btnSave: Button
    private lateinit var btnShare: Button

    private var currentBitmap: Bitmap? = null
    private var cameraUri: Uri? = null

    // Request codes
    private val REQ_CAMERA_FRONT  = 101
    private val REQ_GALLERY_FRONT = 102
    private val REQ_CAMERA_BACK   = 103
    private val REQ_GALLERY_BACK  = 104
    private val REQ_PERMISSIONS    = 200

    private var pendingAction: (() -> Unit)? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        ivFront          = findViewById(R.id.ivFront)
        ivBack           = findViewById(R.id.ivBack)
        layoutFrontResult = findViewById(R.id.layoutFrontResult)
        layoutBackResult  = findViewById(R.id.layoutBackResult)
        etPlate          = findViewById(R.id.etPlate)
        etChassis        = findViewById(R.id.etChassis)
        etExpiry         = findViewById(R.id.etExpiry)
        btnGenerate      = findViewById(R.id.btnGenerate)
        cardBarcode      = findViewById(R.id.cardBarcode)
        ivBarcode        = findViewById(R.id.ivBarcode)
        tvBarcodeData    = findViewById(R.id.tvBarcodeData)
        btnSave          = findViewById(R.id.btnSave)
        btnShare         = findViewById(R.id.btnShare)

        findViewById<Button>(R.id.btnCaptureFront).setOnClickListener {
            checkAndRun { openCamera(REQ_CAMERA_FRONT) }
        }
        findViewById<Button>(R.id.btnGalleryFront).setOnClickListener {
            checkAndRun { openGallery(REQ_GALLERY_FRONT) }
        }
        findViewById<Button>(R.id.btnCaptureBack).setOnClickListener {
            checkAndRun { openCamera(REQ_CAMERA_BACK) }
        }
        findViewById<Button>(R.id.btnGalleryBack).setOnClickListener {
            checkAndRun { openGallery(REQ_GALLERY_BACK) }
        }

        btnGenerate.setOnClickListener { generateBarcode() }
        btnSave.setOnClickListener    { saveBarcode() }
        btnShare.setOnClickListener   { shareBarcode() }
    }

    // ── Permission helpers ────────────────────────────────────────────────────

    private fun checkAndRun(action: () -> Unit) {
        val perms = mutableListOf(Manifest.permission.CAMERA)
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q)
            perms.add(Manifest.permission.READ_EXTERNAL_STORAGE)

        val missing = perms.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isEmpty()) {
            action()
        } else {
            pendingAction = action
            ActivityCompat.requestPermissions(this, missing.toTypedArray(), REQ_PERMISSIONS)
        }
    }

    override fun onRequestPermissionsResult(req: Int, perms: Array<String>, results: IntArray) {
        super.onRequestPermissionsResult(req, perms, results)
        if (results.all { it == PackageManager.PERMISSION_GRANTED }) {
            pendingAction?.invoke()
        } else {
            Toast.makeText(this, "ခွင့်ပြုချက် လိုအပ်သည်", Toast.LENGTH_SHORT).show()
        }
        pendingAction = null
    }

    // ── Camera / Gallery ──────────────────────────────────────────────────────

    private fun openCamera(requestCode: Int) {
        val photoFile = File.createTempFile("wtax_", ".jpg", externalCacheDir)
        cameraUri = FileProvider.getUriForFile(this, "$packageName.provider", photoFile)
        val intent = Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE)
        intent.putExtra(android.provider.MediaStore.EXTRA_OUTPUT, cameraUri)
        startActivityForResult(intent, requestCode)
    }

    private fun openGallery(requestCode: Int) {
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        startActivityForResult(intent, requestCode)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return

        when (requestCode) {
            REQ_CAMERA_FRONT  -> cameraUri?.let { processImage(it, isFront = true) }
            REQ_GALLERY_FRONT -> data?.data?.let { processImage(it, isFront = true) }
            REQ_CAMERA_BACK   -> cameraUri?.let { processImage(it, isFront = false) }
            REQ_GALLERY_BACK  -> data?.data?.let { processImage(it, isFront = false) }
        }
    }

    // ── OCR Processing ────────────────────────────────────────────────────────

    private fun processImage(uri: Uri, isFront: Boolean) {
        val stream = contentResolver.openInputStream(uri) ?: return
        val bitmap = BitmapFactory.decodeStream(stream)
        stream.close()

        if (isFront) {
            ivFront.setImageBitmap(bitmap)
            ivFront.scaleType = ImageView.ScaleType.CENTER_CROP
        } else {
            ivBack.setImageBitmap(bitmap)
            ivBack.scaleType = ImageView.ScaleType.CENTER_CROP
        }

        val image = InputImage.fromBitmap(bitmap, 0)
        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

        recognizer.process(image)
            .addOnSuccessListener { result ->
                val fullText = result.text
                if (isFront) {
                    val plate = extractPlateNumber(fullText)
                    etPlate.setText(plate)
                    layoutFrontResult.visibility = View.VISIBLE
                    if (plate.isEmpty())
                        Toast.makeText(this, "ကားနံပတ် မတွေ့ပါ — ကိုယ်တိုင်ဖြည့်ပါ", Toast.LENGTH_LONG).show()
                } else {
                    val chassis = extractChassis(fullText)
                    val expiry  = extractExpiry(fullText)
                    etChassis.setText(chassis)
                    etExpiry.setText(expiry)
                    layoutBackResult.visibility = View.VISIBLE
                    if (chassis.isEmpty() && expiry.isEmpty())
                        Toast.makeText(this, "Data မတွေ့ပါ — ကိုယ်တိုင်ဖြည့်ပါ", Toast.LENGTH_LONG).show()
                }
                checkShowGenerateButton()
            }
            .addOnFailureListener {
                Toast.makeText(this, "OCR မအောင်မြင်ပါ — ကိုယ်တိုင်ဖြည့်ပါ", Toast.LENGTH_LONG).show()
                if (isFront) layoutFrontResult.visibility = View.VISIBLE
                else layoutBackResult.visibility = View.VISIBLE
                checkShowGenerateButton()
            }
    }

    // ── Extract helpers ───────────────────────────────────────────────────────

    // Plate: e.g. 7H/5812 or 2L/2089
    private fun extractPlateNumber(text: String): String {
        val regex = Regex("""(\d{1,2}[A-Z]{1,2}/\d{3,5})""")
        return regex.find(text)?.value ?: ""
    }

    // Chassis No only — Engine No ကို skip လုပ်ပြီး Chassis No တည်းပဲ ယူမယ်
    private fun extractChassis(text: String): String {
        val lines = text.lines()
        val valueRegex = Regex("""([A-Z]{1,5}[0-9]{1,5}[-][0-9]{4,10}|[A-Z]{2,5}[0-9]{5,10})""")

        // Step 1: Find Engine No value first so we can exclude it
        var engineValue = ""
        for (i in lines.indices) {
            val lineUpper = lines[i].uppercase()
            if (lineUpper.contains("ENGINE") && !lineUpper.contains("POWER")) {
                // Engine value on same line
                val stripped = lines[i].replace(Regex("""(?i)engine\s*no\.?\s*"""), "").trim()
                val m = valueRegex.find(stripped)?.value
                if (!m.isNullOrEmpty()) { engineValue = m.uppercase(); break }
                // Engine value on next line
                if (i + 1 < lines.size) {
                    val m2 = valueRegex.find(lines[i + 1].trim())?.value
                    if (!m2.isNullOrEmpty()) { engineValue = m2.uppercase(); break }
                }
            }
        }

        // Step 2: Find Chassis No value, skip engine value
        for (i in lines.indices) {
            val lineUpper = lines[i].uppercase()
            if (lineUpper.contains("CHASSIS")) {
                // Value on same line (after label)
                val stripped = lines[i].replace(Regex("""(?i)chassis\s*no\.?\s*"""), "").trim()
                val m = valueRegex.find(stripped)?.value
                if (!m.isNullOrEmpty() && m.uppercase() != engineValue) return m.uppercase()

                // Value on next line
                for (j in 1..2) {
                    if (i + j < lines.size) {
                        val nextLine = lines[i + j].trim()
                        // Skip lines that look like labels
                        if (nextLine.uppercase().contains("COLOR") ||
                            nextLine.uppercase().contains("GROSS") ||
                            nextLine.isEmpty()) continue
                        val m2 = valueRegex.find(nextLine)?.value
                        if (!m2.isNullOrEmpty() && m2.uppercase() != engineValue) return m2.uppercase()
                    }
                }
            }
        }

        // Step 3: fallback — all candidates minus engine
        val allMatches = valueRegex.findAll(text).map { it.value.uppercase() }
            .filter { it != engineValue }
            .toList()
        return allMatches.firstOrNull() ?: ""
    }

    // Expiry date: dd/MM/yyyy or dd-MM-yyyy
    private fun extractExpiry(text: String): String {
        val regex = Regex("""(\d{2}[/\-]\d{2}[/\-]\d{4})""")
        val match = regex.find(text)?.value ?: return ""
        return match.replace("-", "/")
    }

    private fun checkShowGenerateButton() {
        if (layoutFrontResult.visibility == View.VISIBLE &&
            layoutBackResult.visibility == View.VISIBLE) {
            btnGenerate.visibility = View.VISIBLE
        }
    }

    // ── Barcode Generation ────────────────────────────────────────────────────

    private fun generateBarcode() {
        val plate   = etPlate.text.toString().trim().uppercase()
        val chassis = etChassis.text.toString().trim().uppercase()
        val expiry  = etExpiry.text.toString().trim()

        if (plate.isEmpty())   { etPlate.error   = "ဖြည့်ပါ"; etPlate.requestFocus();   return }
        if (chassis.isEmpty()) { etChassis.error = "ဖြည့်ပါ"; etChassis.requestFocus(); return }
        if (expiry.isEmpty())  { etExpiry.error  = "ဖြည့်ပါ"; etExpiry.requestFocus();  return }

        // Stack all three — no separator
        val barcodeData = "$plate$chassis$expiry"

        try {
            val writer = MultiFormatWriter()
            val hints  = mapOf(EncodeHintType.MARGIN to 2)
            val matrix = writer.encode(barcodeData, BarcodeFormat.PDF_417, 900, 300, hints)

            val w = matrix.width; val h = matrix.height
            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            for (x in 0 until w)
                for (y in 0 until h)
                    bmp.setPixel(x, y, if (matrix[x, y]) Color.BLACK else Color.WHITE)

            currentBitmap = bmp
            ivBarcode.setImageBitmap(bmp)
            tvBarcodeData.text = "Data: $barcodeData"
            cardBarcode.visibility = View.VISIBLE

        } catch (e: Exception) {
            Toast.makeText(this, "Barcode ထုတ်မရပါ: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    // ── Save / Share ──────────────────────────────────────────────────────────

    private fun saveBarcode() {
        val bmp = currentBitmap ?: return
        val name = "WheelTax_${etPlate.text.toString().replace("/","-")}_${System.currentTimeMillis()}.png"
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val cv = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, name)
                    put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                    put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/WheelTaxBarcode")
                }
                val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)
                uri?.let {
                    contentResolver.openOutputStream(it)?.use { out ->
                        bmp.compress(Bitmap.CompressFormat.PNG, 100, out)
                    }
                    Toast.makeText(this, "✅ Pictures/WheelTaxBarcode မှာ သိမ်းပြီးပြီ", Toast.LENGTH_LONG).show()
                }
            } else {
                val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "WheelTaxBarcode")
                dir.mkdirs()
                FileOutputStream(File(dir, name)).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
                Toast.makeText(this, "✅ သိမ်းပြီးပြီ", Toast.LENGTH_LONG).show()
            }
        } catch (e: Exception) {
            Toast.makeText(this, "သိမ်းမရပါ: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun shareBarcode() {
        val bmp = currentBitmap ?: return
        try {
            val dir  = File(cacheDir, "barcodes").also { it.mkdirs() }
            val file = File(dir, "barcode_${etPlate.text.toString().replace("/","-")}.png")
            FileOutputStream(file).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
            val uri = FileProvider.getUriForFile(this, "$packageName.provider", file)
            startActivity(Intent.createChooser(
                Intent(Intent.ACTION_SEND).apply {
                    type = "image/png"
                    putExtra(Intent.EXTRA_STREAM, uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }, "Barcode မျှဝေမည်"
            ))
        } catch (e: Exception) {
            Toast.makeText(this, "မျှဝေမရပါ: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }
}
